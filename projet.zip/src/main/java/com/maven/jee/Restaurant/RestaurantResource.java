package com.maven.jee.Restaurant;


import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.config.inject.ConfigProperty;



@Path("restaurant")
public class RestaurantResource {
    private static List<Restaurant> restaurants = new ArrayList<>();
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/list")
    public Response listMembers() {
        return Response.ok(restaurants).build();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/insert")
    public Response insertMember(Restaurant restaurant) {
        restaurants.add(restaurant);
        return Response.ok(restaurants).build();
    }
}
