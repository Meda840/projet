package com.maven.jee.Restaurant;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data

public class Restaurant {
    @Id
    private long id ;
    private String restauName;
    private String Category;
}
